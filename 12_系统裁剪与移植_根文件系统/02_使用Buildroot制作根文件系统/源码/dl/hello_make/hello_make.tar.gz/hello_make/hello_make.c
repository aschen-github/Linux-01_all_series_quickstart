#include <stdio.h>

int main(int argc, char **argv)
{
	printf("hello, I am a make project\n");
	return 0;
}
