#include <stdio.h>

int main(int argc, char **argv)
{
	printf("hello, I am a cmake project\n");
	return 0;
}
