{application,replayq,
             [{description,"A Disk Queue for Log Replay in Erlang"},
              {vsn,"0.3.7"},
              {registered,[]},
              {applications,[kernel,stdlib]},
              {env,[]},
              {modules,[replayq]},
              {licenses,["Apache 2.0"]},
              {links,[{"GitHub","https://github.com/emqx/replayq"}]}]}.
