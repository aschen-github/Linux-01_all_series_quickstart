#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QLabel *tempLabel; // Declare the QLabel for temperature
    QLabel *humiLabel; // Declare the QLabel for humidity
    
private slots:
    void on_burnButton_clicked();

    void on_beep1Button_clicked();

    void on_beep2Button_clicked();

    void on_led1Button_clicked();

    void on_led2Button_clicked();

    void on_led3Button_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
