#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <stdlib.h>
#include <QProcess>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    tempLabel = this->findChild<QLabel*>("tempLabel");
    humiLabel = this->findChild<QLabel*>("humiLabel");
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_burnButton_clicked()
{
    QProcess process;
    process.start("/bin/burn.sh");
    process.waitForFinished(-1); // Wait for the process to finish
}

void MainWindow::on_beep1Button_clicked()
{
    static int state  = 1;
    char cmd[100];
    sprintf(cmd, "/bin/sensor_test.sh beep1 %s", state ? "on" : "off");

    QProcess process;
    process.start(cmd);
    process.waitForFinished(-1); // Wait for the process to finish

    state = !state;
}

void MainWindow::on_beep2Button_clicked()
{
    static int state  = 1;
    char cmd[100];
    sprintf(cmd, "/bin/sensor_test.sh beep2 %s", state ? "on" : "off");

    QProcess process;
    process.start(cmd);
    process.waitForFinished(-1); // Wait for the process to finish

    state = !state;
}

void MainWindow::on_led1Button_clicked()
{
    static int state  = 1;
    char cmd[100];
    sprintf(cmd, "/bin/sensor_test.sh led1 %s", state ? "on" : "off");

    QProcess process;
    process.start(cmd);
    process.waitForFinished(-1); // Wait for the process to finish

    state = !state;
}

void MainWindow::on_led2Button_clicked()
{
    static int state  = 1;
    char cmd[100];
    sprintf(cmd, "/bin/sensor_test.sh led2 %s", state ? "on" : "off");

    QProcess process;
    process.start(cmd);
    process.waitForFinished(-1); // Wait for the process to finish

    state = !state;
}

void MainWindow::on_led3Button_clicked()
{
    static int state  = 1;
    char cmd[100];
    sprintf(cmd, "/bin/sensor_test.sh led3 %s", state ? "on" : "off");

    QProcess process;
    process.start(cmd);
    process.waitForFinished(-1); // Wait for the process to finish

    state = !state;
}
