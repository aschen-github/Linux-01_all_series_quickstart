#include "mainwindow.h"
#include <QApplication>
#include <QTimer>
#include <QProcess>
#include <QByteArray>
#include <QString>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    // Create a QTimer
    QTimer timer;

    // Connect the timeout signal to a slot
    QObject::connect(&timer, &QTimer::timeout, [&w]() {
        QProcess process;
        process.start("/bin/sensor_test.sh temp");
        process.waitForFinished(-1); // Wait for the process to finish

        QByteArray output = process.readAllStandardOutput();
        QString temperature = QString::fromUtf8(output).trimmed();

        // Update the tempLabel with the temperature value
        w.tempLabel->setText(temperature);

        process.start("/bin/sensor_test.sh humi");
        process.waitForFinished(-1); // Wait for the process to finish

        output = process.readAllStandardOutput();
        QString humity = QString::fromUtf8(output).trimmed();

        // Update the tempLabel with the temperature value
        w.humiLabel->setText(humity);
    });

    // Set the timer interval to 2000 milliseconds (2 seconds)
    timer.setInterval(2000);

    // Start the timer
    timer.start();

    return a.exec();
}
